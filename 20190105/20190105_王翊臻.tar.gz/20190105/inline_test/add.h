#ifdef __ADD_H_
#define __ADD_H_

inline
int add(int x, int y)
{
	return x + y;
}

#endif
