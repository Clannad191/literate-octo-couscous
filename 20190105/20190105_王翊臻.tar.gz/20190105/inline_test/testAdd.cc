#include "add.h"
#include <iostream>

using std::cout;
using std::endl;


int main()
{
	int a = 3, b = 5;
	cout << "a + b = " << add(a, b) << endl;
	return 0;
}
