#include <iostream>
using namespace std;

int main(void)
{
	int a;
	int b;
	cin >> a;
	cin >> b;
	cout << "a=" << a << ", b=" << b << endl;
	cout << "hello, world" << endl;
}
